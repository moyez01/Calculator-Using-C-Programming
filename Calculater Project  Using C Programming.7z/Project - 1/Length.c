#include<stdio.h>
#include<conio.h>

int main()
{
    float centimeter, miter, kilometer, convert_number;
    int length_number;
    printf("\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Centimeter to Miter");
    printf("\n\t\t\t\tPress 2 to Convert Centimeter to Kilometer");
    printf("\n\t\t\t\tPress 3 to Convert Miter to Centimeter");
    printf("\n\t\t\t\tPress 4 to Convert Miter to Kilometer");
    printf("\n\t\t\t\tPress 5 to Convert Kilometer to Centimeter");
    printf("\n\t\t\t\tPress 6 to Convert Kilometer to Miter");
    printf("\n\t\t\t\tPress Any Key to Continue...");
    scanf("%d", &length_number);
    system ("cls");
    printf("\n\n\n\n\n\n\n\n\n\n\n");
    switch(length_number){
    case 1:
        printf("\n\t\t\t\t\t\tCentimeter : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tMeter      : %.3f\n", convert_number / 100);
        break;
    case 2:
        printf("\n\t\t\t\t\t\tCentimeter : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKilometer  : %.3f\n", convert_number / 1000);
        break;
    case 3:
        printf("\n\t\t\t\t\t\tMiter      : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tCentimeter : %.3f\n", convert_number * 100);
        break;
    case 4:
        printf("\n\t\t\t\t\t\tMiter     : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKilometer : %.3f\n", convert_number / 100);
        break;
    case 5:
        printf("\n\t\t\t\t\t\tKilometer  : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tCentimeter : %.3f\n", convert_number * 1000);
        break;
    case 6:
        printf("\n\t\t\t\t\t\tKilometer : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tMiter     : %.3f\n", convert_number * 100);
        break;
        }

    getch();
    return 0;
}
