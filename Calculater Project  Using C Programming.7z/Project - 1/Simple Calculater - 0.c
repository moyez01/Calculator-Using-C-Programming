#include<stdio.h>
#include<conio.h>

void simple_calculator()
{
    printf("\n\n\n\n\n\n\n\n");
    printf("\t\t\t\t\tPress 1 to  Calculate Addition\n");
    printf("\t\t\t\t\tPress 2 to  Calculate Subtraction\n");
    printf("\t\t\t\t\tPress 3 to  Calculate Multiply\n");
    printf("\t\t\t\t\tPress 4 to  Calculate Divided\n");
    printf("\t\t\t\t\tPress 5 to  Calculate Power\n");
    printf("\t\t\t\t\tPress 6 to  Calculate Root\n");
    printf("\t\t\t\t\tPress any Key to Continue...");
    int number;
    int a, b, result;
    scanf("%d", &number);
    system("cls");
    switch(number){
    case 1:
        printf("\n\n\n\n\n\n\n\n\n\n");
        printf("\t\t\t\t\tEnter the first value  : ");
        scanf("%d", &a);
        printf("\t\t\t\t\tEnter the Second value : ");
        scanf("%d", &b);
        result = a + b;
        printf("\t\t\t\t\tAddition = %d\n", result);
        break;
        case 2:
        printf("\n\n\n\n\n\n\n\n\n\n");
        printf("\t\t\t\t\tEnter the first value  : ");
        scanf("%d", &a);
        printf("\t\t\t\t\tEnter the Second value : ");
        scanf("%d", &b);
        result = a - b;
        printf("\t\t\t\t\tSubtraction = %d\n", result);
        break;
        case 3:
        printf("\n\n\n\n\n\n\n\n\n\n");
        printf("\t\t\t\t\tEnter the first value  : ");
        scanf("%d", &a);
        printf("\t\t\t\t\tEnter the Second value : ");
        scanf("%d", &b);
        result = a * b;
        printf("\t\t\t\t\tMultiply = %d\n", result);
        break;
        case 4:
        printf("\n\n\n\n\n\n\n\n\n\n");
        printf("\t\t\t\t\tEnter the first value  : ");
        scanf("%d", &a);
        printf("\t\t\t\t\tEnter the Second value : ");
        scanf("%d", &b);
        float result = (float) a / (float) b;
        printf("\t\t\t\t\tDivided = %.2f\n", result);
        break;
    }
    getch();
    return 0;
}
