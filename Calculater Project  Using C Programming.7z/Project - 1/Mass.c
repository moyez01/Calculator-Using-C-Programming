#include<stdio.h>
#include<conio.h>

void mass()
{
    float convert_number;
    int mass_number;
    printf("\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Centigram to Gram");
    printf("\n\t\t\t\tPress 2 to Convert Centimeter to Kilogram");
    printf("\n\t\t\t\tPress 3 to Convert Gram to Centigram");
    printf("\n\t\t\t\tPress 4 to Convert Gram to Kilogram");
    printf("\n\t\t\t\tPress 5 to Convert Kilogram to Centigram");
    printf("\n\t\t\t\tPress 6 to Convert Kilogram to Gram");
    printf("\n\t\t\t\tPress Any Key to Continue...");
    scanf("%d", &mass_number);
    system ("cls");
    printf("\n\n\n\n\n\n\n\n\n\n\n");
    switch(mass_number){
    case 1:
        printf("\n\t\t\t\t\t\tCentigram : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tGram      : %.3f\n", convert_number / 100);
        break;
    case 2:
        printf("\n\t\t\t\t\t\tCentigram : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKilogram  : %.3f\n", convert_number / 1000);
        break;
    case 3:
        printf("\n\t\t\t\t\t\tGram      : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tCentigram : %.3f\n", convert_number * 100);
        break;
    case 4:
        printf("\n\t\t\t\t\t\tGram     : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKilogram : %.3f\n", convert_number / 100);
        break;
    case 5:
        printf("\n\t\t\t\t\t\tKilogram  : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tCentigram : %.3f\n", convert_number * 1000);
        break;
    case 6:
        printf("\n\t\t\t\t\t\tKilogram : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tGram     : %.3f\n", convert_number * 100);
        break;
        }

    getch();
    return 0;
}
