#include<stdio.h>

void birth_calculator()

{

    int birth_date, birth_month, birth_day;
    int present_date, present_month, present_day;
    int date, month, day;
    printf("\n\n\n\n\n\n\n\n\n");
    printf("  \t\t\t\tEnter Your Present Date Month Day : ");
    scanf("%d %d %d", &present_date, &present_month, &present_day);
    printf("  \t\t\t\tEnter Your Birth Date Month Day   : ");
    scanf("%d %d %d", &birth_date, &birth_month, &birth_day);
    printf("  \t\t\t\tYour Birth Calculate in Year Month Day Below\n");
    printf("\t\t");

    if(present_month > 12 || birth_month > 12 || present_day > 31 || birth_day > 31){
        printf("\t\t\t\tError Calculation\n");
    }
    else{
    //d>=m>=d>=
    if((present_date > birth_date || present_date == birth_date) && (present_month > birth_month || present_month == birth_month) && (present_day > birth_day || present_day == birth_day)){
        date = present_date - birth_date;
        month = present_month - birth_month;
        day = present_day - birth_day;
        printf("\t\t\t\tYear - Month - Day\n");
        printf("\t\t\t\t\t\t %d -    %d -    %d\n", date, month, day + 1);
    }

    //d>=m>=d<=
    else if((present_date > birth_date || present_date == birth_date) && (present_month > birth_month || present_month == birth_month) && (present_day < birth_day || present_day == birth_day)){
        if(present_month == 1 || present_month == 3 || present_month == 5 || present_month == 7 || present_month == 8 || present_month == 10 || present_month == 12 ){
            date = present_date - birth_date;
            month = (present_month - 1) - birth_month;
            day = (present_day + 31) - birth_day;
            printf("\t\t\t\tYear - Month - Day\n");
            printf("\t\t\t\t\t\t %d -    %d -    %d\n", date, month, day + 1);
            }
        else{
            if(present_month != 2){
                date = present_date - birth_date;
                month = (present_month - 1) - birth_month;
                day = (present_day + 30) - birth_day;
                printf("\t\t\t\tYear - Month - Day\n");
                printf("\t\t\t\t\t\t %d -    %d -    %d\n", date, month, day + 1);
            }
            else{
                if(present_date % 4 != 0){
                date = present_date - birth_date;
                month = (present_month - 1) - birth_month;
                day = (present_day + 29) - birth_day;
                printf("\t\t\t\tYear - Month - Day\n");
                printf("\t\t\t\t\t\t %d -    %d -    %d\n", date, month, day + 1);
                }
                else{
                date = present_date - birth_date;
                month = (present_month - 1) - birth_month;
                day = (present_day + 28) - birth_day;
                printf("\t\t\t\tYear - Month - Day\n");
                printf("\t\t\t\t\t\t %d -    %d -    %d\n", date, month, day + 1);
                }
            }
        }
    }

    //d>=m<=d>=
    else if((present_date > birth_date || present_date == birth_date) && (present_month < birth_month || present_month == birth_month) && (present_day > birth_day || present_day == birth_day)){
        date = (present_date - 1) - birth_date;
        month = (present_month + 12) - birth_month;
        day = present_day - birth_day;
        printf("\t\t\t\tYear - Month - Day\n");
        printf("\t\t\t\t\t\t %d -    %d -    %d\n", date, month, day + 1);
    }

    //d>=m=<d<=
    else if((present_date > birth_date || present_date == birth_date) && (present_month < birth_month || present_month == birth_month) && (present_day < birth_day || present_day == birth_day)){
        if(present_month == 1 || present_month == 3 || present_month == 5 || present_month == 7 || present_month == 8 || present_month == 10 || present_month == 12 ){
            date = (present_date - 1) - birth_date;
            month = (present_month + 11) - birth_month;
            day = (present_day + 31) - birth_day;
            printf("\t\t\t\tYear - Month - Day\n");
            printf("\t\t\t\t\t\t %d -    %d -    %d\n", date, month, day + 1);
            }
        else{
            if(present_month != 2){
                date = (present_date - 1) - birth_date;
                month = (present_month + 11) - birth_month;
                day = (present_day + 30) - birth_day;
                printf("\t\t\t\tYear - Month - Day\n");
                printf("\t\t\t\t\t\t %d -    %d -    %d\n", date, month, day + 1);
            }
            else{
                if(present_date % 4 != 0){
                date = (present_date - 1) - birth_date;
                month = (present_month + 11) - birth_month;
                day = (present_day + 29) - birth_day;
                printf("\t\t\t\tYear - Month - Day\n");
                printf("\t\t\t\t\t\t %d -    %d -    %d\n", date, month, day + 1);
                }
                else{
                date = (present_date - 1) - birth_date;
                month = (present_month + 11) - birth_month;
                day = (present_day + 28) - birth_day;
                printf("\t\t\t\tYear - Month - Day\n");
                printf("\t\t\t\t\t\t %d -    %d -    %d\n", date, month, day + 1);
                }
            }
        }
    }

    else{
        printf("\t\t\t\t\t\tError Calculation\n");
    }
    }

    getch();
    return 0;
}
