#include<stdio.h>

void simple_calculator()
{
    float a, b;
    float result;
    int count = 0;
    char check;
    printf("Inter the value and calculate : ");
    scanf("%f %c %f", &a, &check, &b);
    if(check == '+'){
            result = a + b;
    }
    else if(check == '-'){
            result = a - b;
    }
    else if(check == '*'){
            result = a * b;
    }
    else if(check == '/'){
            result = a / b;
            count++;
    }

    scanf("%c", &check);
    float c;
    while(check != '+' && check != '-' && check != '*' && check != '/' && check != '\n'){
    scanf("%c", &check);
            scanf("%f", &c);
        if(check == '+'){
            result = result + c;
    }
    else if(check == '-'){
            result = result - c;
    }
    else if(check == '*'){
            result = result * c;
    }
    else if(check == '/'){
            result =  result / c;
            count++;
    }
     scanf("%c", &check);
    }


    if(count != 0){
    printf("Result = %.2f\n", result);
    }
    else{
      printf("Result = %.0f\n", result);
    }

    return 0;
}
