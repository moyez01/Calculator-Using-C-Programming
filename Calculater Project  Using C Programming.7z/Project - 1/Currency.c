
#include<stdio.h>
#include<conio.h>

void currency()
{
    system("color 4a");
    float centimeter, miter, kilometer, convert_number;
    int energy_number;
    printf("\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Bangladeshi Taka to US Dollar");
    printf("\n\t\t\t\tPress 2 to Convert Bangladeshi Taka to Euro");
    printf("\n\t\t\t\tPress 3 to Convert US Dollar to Bangladeshi Taka");
    printf("\n\t\t\t\tPress 4 to Convert US Dollar to Euro");
    printf("\n\t\t\t\tPress 5 to Convert Euro to Bangladeshi Taka");
    printf("\n\t\t\t\tPress 6 to Convert Euro to US Dollar");
    printf("\n\t\t\t\tPress Any Key to Continue...");
    scanf("%d", &energy_number);
    system ("cls");
    //clrscr();
    printf("\n\n\n\n\n\n\n\n\n\n\n");
    switch(energy_number){
    case 1:
        printf("\n\t\t\t\t\t\tBangladeshi Taka : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tUS Dollar   : %.2f\n\n", convert_number *  0.0122133);
        break;
    case 2:
        printf("\n\t\t\t\t\t\tBangladeshi Taka : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tEuro        : %.3f\n\n", convert_number * 0.0103774);
        break;
    case 3:
        printf("\n\t\t\t\t\t\tUS Dollar    : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\Bangladeshi Taka : %10.f\n\n", 81.8783 * convert_number);
        break;
    case 4:
        printf("\n\t\t\t\t\t\tUS Dollar     : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tEuro      : %.3f\n\n", convert_number * 0.848139);
        break;
    case 5:
        printf("\n\t\t\t\t\t\tEuro       : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tBangladeshi Taka : %.3f\n\n", convert_number * 96.4136);
        break;
    case 6:
        printf("\n\t\t\t\t\t\tEuro     : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tUS Dollar : %f\n\n", convert_number * 1.17905);
        break;
        }

    getch();
    return 0;
}
