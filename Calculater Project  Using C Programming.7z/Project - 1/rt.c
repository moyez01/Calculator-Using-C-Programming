#include<stdio.h>

  struct employe
  {
      char empno[20];
      char empname[20];
      char salary[20];
  }emp;

add()
{
    FILE *Rec;
    Rec=fopen("D:\\R.txt","a");
    printf("input employee no name and salary : ");
    scanf("%s %s %s",&emp.empno,&emp.empname,&emp.salary);
    fwrite(&emp,sizeof(emp),1,Rec);
    fprintf(Rec,"\n");

    fclose(Rec);
}


int show()
{
    FILE *fp;
    fp=fopen("D:\\R.txt","r");
    while(fread(&emp,sizeof(emp),1,fp)){
    printf("%s %s %s",emp.empno, emp.empname, emp.salary);
    }
    fclose(fp);

}
/*int search()
{
    int number;
    scanf("%d", &number);
    switch(number){
    case 1:
    Rec=fopen("D:\\R.txt","a");
    printf("input employee no name and salary : ");
    scanf("%s %s %s",&emp.empno,&emp.empname,&emp.salary);
    fwrite(&emp,sizeof(emp),1,Rec);
    fclose(Rec);
    break;
    case 2:
    fp=fopen("D:\\R.txt","r");
    while(fread(&emp,sizeof(emp),1,fp)){
    printf("%s %s %s",emp.empno, emp.empname, emp.salary);
    break;
    }
    fclose(fp);
    }

}
*/
main()
{
    add();
    show();
    //search();
 return 0;
}


