#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <windows.h>
#include<time.h>
#define MAX_SIZE 100


void clear();
void delay( int mseconds);


void clear()
{
    system("PAUSE");
    system("CLS");
}
void delay( int mseconds)
{
    clock_t goal = mseconds + clock();
    while (goal > clock());
}



void add_contact();
void number_list();
void search_contact();
void edit_contact();
void delete_contact();



int main()
{
    printf("Press 1 to Add New Contact");
    printf("\nPress 2 to See Number List");
    printf("\nPress 3 to Search Contact");
    printf("\nPress 4 to Edit Contact Info");
    printf("\nPress 5 to Delete Contact");
    printf("\nEnter Your Choice... ");
    int choice;
    scanf("%d", &choice);
    printf("\n");
    while(choice > 0 && choice < 6){
        switch(choice){
            case 1:
            add_contact();
            printf("\n");
            clear();
            break;
            case 2:
            number_list();
            printf("\n");
            clear();
            break;
            case 3:
            search_contact();
            printf("\n");
            clear();
            break;
            case 4:
            edit_contact();
            printf("\n");
            clear();
            break;
            case 5:
            delete_contact();
            printf("\n");
            clear();
            break;
        }
    printf("Press 1 to Add New Contact");
    printf("\nPress 2 to See Number List");
    printf("\nPress 3 to Search Contact");
    printf("\nPress 4 to Edit Contact Info");
    printf("\nPress 5 to Delete Contact");
    printf("\nEnter Your Choice... ");
    scanf("%d", &choice);
    printf("\n");
    }

}





void add_contact()
{
    struct add_number
{
    char first_name[30];
    char last_name[30];
    int number[30];
};
    struct add_number n[200];
    FILE *phonebook;
    int i, insert, size;
    printf("How Many Number Do You Want to Add Now : ");
    scanf("%d", &size);
    for(i = 0; i < size; i++){
        printf("Enter First Name : ");
        scanf("%s",&n[i].first_name);
        printf("Enter Last Name : ");
        scanf("%s",&n[i].last_name);
        printf("Enter Contact : ");
        scanf("%s",&n[i].number);
    }
    phonebook = fopen("Phone_book.txt","a");
    for(i = 0; i < size; i++){
    fprintf(phonebook,"\nName : %s %s\nContact : %s", n[i].first_name, n[i].last_name, n[i].number);
    }
     for(i = 0; i < size; i++){
        printf("\nName : ");
        printf("%s ", n[i].first_name);
        printf("%s", n[i].last_name);
        printf("\nContact : ");
        printf("%s", n[i].number);
    }
    Sleep(500);
    printf("\nContact is Successfully Added\n");
    fclose(phonebook);

    return 0;
}




void number_list()
{
    struct add_number
{
    char first_name[30];
    char last_name[30];
    char number[30];
};
    system("cls");
    struct add_number n[200];
    int i, insert, size;
    FILE *numberlist;
    char name[20];
    char symble1[5];
    char symble2[5];
    char contact[20];
    printf("Name and Number List : ");
    numberlist = fopen("Phone_book.txt","r");
    while(fread(&n,sizeof(n),1,numberlist)){
        printf("\n%s ", name);
        printf("%s", symble1);
        printf(" %s ", n[i].first_name);
        printf("%s", n[i].last_name);
        printf("\n%s ", contact);
        printf("%s", symble2);
        printf(" %s", n[i].number);
    }
    printf("\n");
    fclose(numberlist);

    return 0;
}




void search_contact()
{
    struct add_number
{
    char first_name[30];
    char last_name[30];
    char number[30];
};
    struct add_number n[200];
    int i, insert, size;
    FILE *fsearch;
    char search_name[20];
    char name[20];
    char symble1[5];
    char symble2[5];
    char contact[20];
    printf("Please Enter Number to get Name Info : ");
    scanf("%s", &search_name);
    fsearch = fopen("Phone_book.txt","r");
    printf("\nSearch Name Info : ");
    for(i = 0; i < MAX_SIZE; i++){
        fscanf(fsearch,"%s %s %s %s %s %s %s", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
        if(strcmp(search_name,n[i].first_name) == 0 || strcmp(search_name,n[i].last_name) == 0 ||strcmp(search_name,n[i].number) == 0){
            printf("\n%s ", name);
            printf("%s", symble1);
            printf(" %s ", n[i].first_name);
            printf("%s", n[i].last_name);
            printf("\n%s ", contact);
            printf("%s", symble2);
            printf(" %s", n[i].number);
            break;
        }
    }
    printf("\n");
    fclose(fsearch);

    return 0;
}




void edit_contact()
{
    struct add_number
{
    char first_name[30];
    char last_name[30];
    char number[30];
};
    struct add_number n[200];
    int i, insert, size;
    FILE *fsearch;
    FILE *fedit;
    char search_name[20];
    char name[20];
    char symble1[5];
    char symble2[5];
    char contact[20];
    printf("Please Enter Number to get Name Info : ");
    scanf("%s", &search_name);
    fsearch = fopen("Phone_book.txt","r");
    printf("\nSearch Name Info : ");
    for(i = 0; i < MAX_SIZE; i++){
        fscanf(fsearch,"%s %s %s %s %s %s %s", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
        if(strcmp(search_name,n[i].first_name) == 0 || strcmp(search_name,n[i].last_name) == 0 ||strcmp(search_name,n[i].number) == 0){
            printf("\n%s ", name);
            printf("%s", symble1);
            printf(" %s ", n[i].first_name);
            printf("%s", n[i].last_name);
            printf("\n%s ", contact);
            printf("%s", symble2);
            printf(" %s", n[i].number);
            break;
        }
    }
    printf("\n");
    fclose(fsearch);
    fsearch = fopen("Phone_book.txt","r");
    int count = 0;
    for(i = 0; i < MAX_SIZE; i++){
        fscanf(fsearch,"%s %s %s %s %s %s %s", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
        if(strlen(n[i].first_name) == NULL){
            break;
        }
        count++;
    }
    fedit = fopen("Phone_book5.txt", "w");
    int j;
    for(i = 0; i < count; i++){
        fscanf(fsearch,"%s %s %s %s %s %s %s", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
        if(strcmp(search_name,n[i].first_name) == 0 || strcmp(search_name,n[i].last_name) == 0 || strcmp(search_name,n[i].number) == 0){
        printf("Enter First Name : ");
        scanf("%s",&n[i].first_name);
        printf("Enter Last Name : ");
        scanf("%s",&n[i].last_name);
        printf("Enter Contact : ");
        scanf("%s",&n[i].number);
        }
        fprintf(fedit,"%s %s %s %s\n%s %s %s\n", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
    }
    remove("Phone_book.txt");
    rename("Phone_book5.txt", "Phone_book.txt");
    Sleep(1000);
    delay(1000);
    printf("\a");
    printf("\nNumber is Successfully Edited\n");
    fclose(fsearch);
    fclose(fedit);

    return 0;
}




void delete_contact()
{
    struct add_number
{
    char first_name[30];
    char last_name[30];
    char number[30];
};
    struct add_number n[200];
    int i, insert, size;
    FILE *fsearch;
    FILE *fdelete;
    char search_name[20];
    char name[20];
    char symble1[5];
    char symble2[5];
    char contact[20];
    printf("Please Enter Number to get Name Info : ");
    scanf("%s", &search_name);
    fsearch = fopen("Phone_book.txt","r");
    printf("\nSearch Name Info : ");
    for(i = 0; i < MAX_SIZE; i++){
        fscanf(fsearch,"%s %s %s %s %s %s %s", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
        if(strcmp(search_name,n[i].first_name) == 0 || strcmp(search_name,n[i].last_name) == 0 ||strcmp(search_name,n[i].number) == 0){
            printf("\n%s ", name);
            printf("%s", symble1);
            printf(" %s ", n[i].first_name);
            printf("%s", n[i].last_name);
            printf("\n%s ", contact);
            printf("%s", symble2);
            printf(" %s", n[i].number);
            break;
        }
    }
    printf("\n");
    fclose(fsearch);
    fsearch = fopen("Phone_book.txt","r");
    int count = 0;
    for(i = 0; i < MAX_SIZE; i++){
        fscanf(fsearch,"%s %s %s %s %s %s %s", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
        if(strlen(n[i].first_name) == NULL){
            break;
        }
        count++;
    }
    fdelete = fopen("Phone_book5.txt", "w");
    int j;
    for(i = 0; i < count; i++){
        fscanf(fsearch,"%s %s %s %s %s %s %s", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
        if(strcmp(search_name,n[i].first_name) == 0 || strcmp(search_name,n[i].last_name) == 0 || strcmp(search_name,n[i].number) == 0){
            j = i + 1;
            for(i = j; i < count; i++){
            fscanf(fsearch,"%s %s %s %s %s %s %s", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
            fprintf(fdelete,"%s %s %s %s\n%s %s %s\n", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
            }
            break;
        }
        fprintf(fdelete,"%s %s %s %s\n%s %s %s\n", name, symble1, n[i].first_name, n[i].last_name, contact, symble2, n[i].number);
    }
    fclose(fsearch);
    fclose(fdelete);
    remove("Phone_book.txt");
    rename("Phone_book5.txt", "Phone_book.txt");
    Sleep(1000);
    printf("\a");
    printf("\nNumber is Successfully Deleted\n");

    return 0;
}


