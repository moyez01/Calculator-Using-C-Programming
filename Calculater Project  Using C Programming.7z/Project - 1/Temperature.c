#include<stdio.h>
#include<conio.h>

void temperature()
{
    float convert_number;
    int temperature_number;
    printf("\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Celsius to Fahrenheit");
    printf("\n\t\t\t\tPress 2 to Convert Celsius to Kelvin");
    printf("\n\t\t\t\tPress 3 to Convert Fahrenheit to Celsius");
    printf("\n\t\t\t\tPress 4 to Convert Fahrenheit to Kelvin");
    printf("\n\t\t\t\tPress 5 to Convert Kelvin to Celsius");
    printf("\n\t\t\t\tPress 6 to Convert Kelvin to Fahrenheit");
    printf("\n\t\t\t\tPress Any Key to Continue...");
    scanf("%d", &temperature_number);
    system ("cls");
    printf("\n\n\n\n\n\n\n\n\n\n\n");
    switch(temperature_number){
    case 1:
        printf("\n\t\t\t\t\t\tCelsius    : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tFahrenheit : %.3f\n", convert_number * 1.8 + 32);
        break;
    case 2:
        printf("\n\t\t\t\t\t\tCelsius : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKelvin  : %.3f\n", convert_number + 273.15);
        break;
    case 3:
        printf("\n\t\t\t\t\t\tFahrenheit : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tCelsius    : %.3f\n", (convert_number - 32) * .5556);
        break;
    case 4:
        printf("\n\t\t\t\t\t\tFahrenheit : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKelvin     : %.3f\n", (convert_number + 459.67) * 5/9);
        break;
    case 5:
        printf("\n\t\t\t\t\t\tKelvin  : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tCelsius : %.3f\n",  convert_number - 273.15);
        break;
    case 6:
        printf("\n\t\t\t\t\t\tKelvin     : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tFahrenheit : %.3f\n", convert_number * 9/5 - 459.67);
        break;
        }

    getch();
    return 0;
}
