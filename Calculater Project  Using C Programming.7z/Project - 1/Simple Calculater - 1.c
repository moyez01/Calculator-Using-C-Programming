#include<stdio.h>

void simple_calculator()
{
    int a, b, result;
    char check;
    printf("Inter the value and calculate : ");
    scanf("%d %c %d", &a, &check, &b);
    if(check == '+'){
            result = a + b;
        printf("Summation = %d\n", result);
    }
    else if(check == '-'){
            result = a - b;
        printf("Subtraction = %d\n", result);
    }
    else if(check == '*'){
            result = a * b;
        printf("Multiply = %d\n", result);
    }
    else if(check == '/'){
            float result = (float) a / (float) b;
        printf("Divided = %f\n", result);
    }
    else if(check == '/'){
            result = a / b;
        printf("Divided = %d\n", result);
    }

    return 0;
}
