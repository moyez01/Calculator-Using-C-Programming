#include<stdio.h>
#include<conio.h>

void time()
{
    system("color 4a");
    float centimeter, miter, kilometer, convert_number;
    int energy_number;
    printf("\n\n\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Seconds to Minutes");
    printf("\n\t\t\t\tPress 2 to Convert Seconds to Hours");
    printf("\n\t\t\t\tPress 3 to Convert Minutes to Seconds");
    printf("\n\t\t\t\tPress 4 to Convert Minutes to Hours");
    printf("\n\t\t\t\tPress 5 to Convert Hours to Seconds");
    printf("\n\t\t\t\tPress 6 to Convert Hours to Minutes");
    printf("\n\t\t\t\tPress Any Key to Continue...");
    scanf("%d", &energy_number);
    system ("cls");
    system("color 1b");
    //clrscr();
    printf("\n\n\n\n\n\n\n\n\n\n\n");
    switch(energy_number){
    case 1:
        printf("\n\t\t\t\t\t\tSeconds : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tMinutes : %.2f\n\n", convert_number / 60);
        break;
    case 2:
        printf("\n\t\t\t\t\t\tSeconds : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tHours   : %.5f\n\n", convert_number / 3600);
        break;
    case 3:
        printf("\n\t\t\t\t\t\tMinutes : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tSeconds : %.2f\n\n", 60 * convert_number);
        break;
    case 4:
        printf("\n\t\t\t\t\t\tMinutes : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tHours   : %.2f\n\n", convert_number / 60);
        break;
    case 5:
        printf("\n\t\t\t\t\t\tHours   : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tSeconds : %.2f\n\n", convert_number * 3600);
        break;
    case 6:
        printf("\n\t\t\t\t\t\tHours   : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tMinutes : %.2f\n\n", convert_number * 60);
        break;
        }

    getch();
    return 0;
}
