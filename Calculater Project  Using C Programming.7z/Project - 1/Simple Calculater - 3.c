#include<stdio.h>

void simple_calculator()
{

    float value, result = 0;
    float c;
    int count = 0, i;
    char check;
    printf("Inter the value and calculate : ");
    for(i = 0; i = '\n'; i++){
    scanf("%f", &value);

    if(check == '+'){
            result = result + value;
    }
    else if(check == '-'){
            result = result - value;
    }
    else if(check == '*'){
            result = result * value;
    }
    else if(check == '/'){
            result = result / value;
            count++;
    }
    scanf("%c", &check);
}




    if(count != 0){
    printf("Result = %.2f\n", result);
    }
    else{
      printf("Result = %.0f\n", result);
    }

    return 0;
}

