#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define PI 3.14159265

void clear();
void trigonometric_function()
{
    int n;
    printf("Press 1 to Find the value of sine\n");
    printf("Press 2 to Find the value of sine\n");
    printf("Press 3 to Find the value of sine\n");
    printf("Enter Your Choice to continue... ");
    scanf("%d", &n);
    while(n >= 1 && n <= 3){
        switch(n){
            case 1:
            sine();
            clear();
            break;
            case 2:
            cosine();
            clear();
            break;
            case 3:
            tangent();
            clear();
            break;
        }
        printf("Press 1 to Find the value of sine\n");
        printf("Press 2 to Find the value of sine\n");
        printf("Press 3 to Find the value of sine\n");
        printf("Press any key to continue... ");
        scanf("%d", &n);
    }

}
void clear()
{
    system("PAUSE");
    system("CLS");
}


void sine()
	{
		double input, output;
		printf("\nEnter the value angle of sine : ");
		scanf("%lf", &input);
		output = sin(input*PI/180);
		printf ("Cosine of %.0lf degrees is %.3lf\n", input, output );
		return 0;
	}


void cosine()
	{
		double input, output;
		printf("\nEnter the value angle of cosine : ");
		scanf("%lf", &input);
		output = cos(input*PI/180);
		printf ("Cosine of %.0lf degrees is %.3lf\n", input, output );
		return 0;
	}


void tangent()
	{
		double input, output;
		printf("\nEnter the value angle of tangent : ");
		scanf("%lf", &input);
		output = tan(input*PI/180);
		printf ("Tangent of %.0lf degrees is %.3lf\n", input, output);
		return 0;
	}
