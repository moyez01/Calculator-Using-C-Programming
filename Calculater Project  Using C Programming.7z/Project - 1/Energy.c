#include<stdio.h>
#include<conio.h>

void energy()
{
    system("color 4a");
    float centimeter, miter, kilometer, convert_number;
    int energy_number;
    printf("\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Joules to Kilowatts");
    printf("\n\t\t\t\tPress 2 to Convert Joules to Kilojoules");
    printf("\n\t\t\t\tPress 3 to Convert Kilowatts to Joules");
    printf("\n\t\t\t\tPress 4 to Convert Kilowatts to Kilojoules");
    printf("\n\t\t\t\tPress 5 to Convert Kilojoules to Joules");
    printf("\n\t\t\t\tPress 6 to Convert Kilojoules to Kilowatts");
    printf("\n\t\t\t\tPress Any Key to Continue...");
    scanf("%d", &energy_number);
    system ("cls");
    //clrscr();
    printf("\n\n\n\n\n\n\n\n\n\n\n");
    switch(energy_number){
    case 1:
        printf("\n\t\t\t\t\t\tJoules    : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKilowatts : %.10f\n\n", convert_number / 3600000);
        break;
    case 2:
        printf("\n\t\t\t\t\t\tJoules     : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKiloJoules : %.3f\n\n", convert_number / 1000);
        break;
    case 3:
        printf("\n\t\t\t\t\t\tKilowatts : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tJoules    : %10.f\n\n", 3600000 * convert_number);
        break;
    case 4:
        printf("\n\t\t\t\t\t\tKilowatts  : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKilojoules : %.3f\n\n", convert_number * 3600);
        break;
    case 5:
        printf("\n\t\t\t\t\t\tKilojoules : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tJoules     : %.3f\n\n", convert_number * 1000);
        break;
    case 6:
        printf("\n\t\t\t\t\t\tKilojoules : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKilowatts  : %f\n\n", convert_number / 3600);
        break;
        }

    getch();
    return 0;
}
