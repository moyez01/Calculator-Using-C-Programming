#include <stdio.h>
#include <time.h>

int main ()
{
	time_t time1,time2;
	char get_input [256];
	double dif_sec;

	time (&time1);
	printf ("Please enter the name of your pet: ");
	gets (get_input);

	time (&time2);
	dif_sec = difftime(time2,time1);
	printf ("It took you %.2lf seconds to type the name.\n", time (&time2) );

	return 0;
}
