#include<stdio.h>
int main()
{
    printf("%c", 176);
}
