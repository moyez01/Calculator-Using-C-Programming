#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
int main() {

    int count;
    char operator;
    double firstNumber,secondNumber,result;
    scanf("%lf",&firstNumber);
    scanf(" %c ", &operator);
    switch(operator)
    {
        case '+':
    scanf("%lf",&secondNumber);
    result = firstNumber + secondNumber;
            break;

        case '-':
    scanf("%lf",&secondNumber);
    result = firstNumber - secondNumber;
            break;

        case '*':
    scanf("%lf",&secondNumber);
    result = firstNumber * secondNumber;
            break;

        case '/':
    scanf("%lf",&secondNumber);
    result = firstNumber / secondNumber;
    count++;
            break;

        // operator doesn't match any case constant (+, -, *, /)
        default:
            printf("Error! operator is not correct");
    }
    //scanf(" %c ", &operator);
    while(operator == '+' || operator == '-' || operator == '*' || operator == '/'){
            switch(operator)
    {
        case '+':
    scanf("%lf",&secondNumber);
    result = result + secondNumber;
            break;

        case '-':
    scanf("%lf",&secondNumber);
    result = result - secondNumber;
           break;

        case '*':
    scanf("%lf",&secondNumber);
    result = result * secondNumber;
           break;

        case '/':
    scanf("%lf",&secondNumber);
    result = result / secondNumber;
    count++;
           break;

        // operator doesn't match any case constant (+, -, *, /)
        default:
            break;
    }
    scanf(" %c", &operator);

}

    if(count != 0){
        printf(" %.2f\n\n", result);
    }
    else{
        printf(" %.0f\n\n", result);
    }

return;
}
