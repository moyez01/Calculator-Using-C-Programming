#include<stdio.h>

int main()
{
    int n, i, j, x, y, m, temp;
    scanf("%d", &n);
    for(i = 0; i < n; i++){
        scanf("%d", &m);
        int a[m], b[m];
        for(x = 0; x < m; x++){
            for(j = 0; j < 2; j++){
                scanf("%d", &a[x],b[x]);
            }
        }
        /*for(x = 0; x < m - 1; x++){
            for(y = x + 1; y < m; y++){
                if(a[x] > a[y]){
                temp = a[x];
                a[x] = a[y];
                a[y] = temp;
                }
            }
        }*/
        printf(" Case %d : %d", i+1, a[0]);
    }

    return 0;
}

