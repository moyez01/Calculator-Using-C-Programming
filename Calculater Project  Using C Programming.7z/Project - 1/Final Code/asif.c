#include<stdio.h>

int length();
int temperature();

int main(){
    system("cls");
    int choice;
    printf("Press 1 for Convert Length\n");
    printf("Press 2 for Convert Temperature\n");
    printf("Press 3 to Exit Program\n");
    printf("Enter Your Choice....");
    scanf("%d", &choice);
    system("cls");
    while(choice > 0 && choice < 3){
        switch(choice){
            case 1:
                length();
                getch();
                break;
            case 2:
                temperature();
                getch();
                break;
            case 3:
                break;
        }
    system("cls");
    printf("Press 1 for Convert Length\n");
    printf("Press 2 for Convert Temperature\n");
    printf("Press 3 to Exit Program\n");
    printf("Enter Your Choice....");
    system("cls");
    }
    return 0;
}




int length()
{
    system ("cls");
    float centimeter, miter, kilometer, convert_number;
    int length_number;
    printf("\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Centimeter to Miter");
    printf("\n\t\t\t\tPress 2 to Convert Centimeter to Kilometer");
    printf("\n\t\t\t\tPress 3 to Convert Miter to Centimeter");
    printf("\n\t\t\t\tPress 4 to Convert Miter to Kilometer");
    printf("\n\t\t\t\tPress 5 to Convert Kilometer to Centimeter");
    printf("\n\t\t\t\tPress 6 to Convert Kilometer to Miter");
    printf("\n\t\t\t\tPress 7 to go main menu");
    printf("\n\t\t\t\tPress Any Key to Continue...");
    scanf("%d", &length_number);
    system ("cls");
    printf("\n\n\n\n\n\n\n\n\n\n\n");
    while(length_number > 0 && length_number < 8){
        switch(length_number){
            case 1:
                printf("\n\t\t\t\t\t\tCentimeter : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tMeter      : %.3f\n", convert_number / 100);
                getch();
                break;
            case 2:
                printf("\n\t\t\t\t\t\tCentimeter : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tKilometer  : %.3f\n", convert_number / 1000);
                getch();
                break;
            case 3:
                printf("\n\t\t\t\t\t\tMiter      : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tCentimeter : %.3f\n", convert_number * 100);
                getch();
                break;
            case 4:
                printf("\n\t\t\t\t\t\tMiter     : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tKilometer : %.3f\n", convert_number / 100);
                getch();
                break;
            case 5:
                printf("\n\t\t\t\t\t\tKilometer  : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tCentimeter : %.3f\n", convert_number * 1000);
                getch();
                break;
            case 6:
                printf("\n\t\t\t\t\t\tKilometer : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tMiter     : %.3f\n", convert_number * 100);
                getch();
                break;
            case 7:
                main();
                getch();
                break;
            default:
                break;
        }
        system ("cls");
        printf("\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Centimeter to Miter");
        printf("\n\t\t\t\tPress 2 to Convert Centimeter to Kilometer");
        printf("\n\t\t\t\tPress 3 to Convert Miter to Centimeter");
        printf("\n\t\t\t\tPress 4 to Convert Miter to Kilometer");
        printf("\n\t\t\t\tPress 5 to Convert Kilometer to Centimeter");
        printf("\n\t\t\t\tPress 6 to Convert Kilometer to Miter");
        printf("\n\t\t\t\tPress 7 to go main menu");
        printf("\n\t\t\t\tPress Any Key to Continue...");
        scanf("%d", &length_number);
        system ("cls");
        printf("\n\n\n\n\n\n\n\n\n\n\n");
    }
    return 0;
}




int temperature()
{
    system ("cls");
    float convert_number;
    int temperature_number;
    printf("\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Celsius to Fahrenheit");
    printf("\n\t\t\t\tPress 2 to Convert Celsius to Kelvin");
    printf("\n\t\t\t\tPress 3 to Convert Fahrenheit to Celsius");
    printf("\n\t\t\t\tPress 4 to Convert Fahrenheit to Kelvin");
    printf("\n\t\t\t\tPress 5 to Convert Kelvin to Celsius");
    printf("\n\t\t\t\tPress 6 to Convert Kelvin to Fahrenheit");
    printf("\n\t\t\t\tPress 7 to go main menu");
    printf("\n\t\t\t\tPress Any Key to Continue...");
    scanf("%d", &temperature_number);
    system ("cls");
    printf("\n\n\n\n\n\n\n\n\n\n\n");
    while(temperature_number > 0 && temperature_number < 8){
        switch(temperature_number){
            case 1:
                printf("\n\t\t\t\t\t\tCelsius    : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tFahrenheit : %.3f\n", convert_number * 1.8 + 32);
                getch();
                break;
            case 2:
                printf("\n\t\t\t\t\t\tCelsius : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tKelvin  : %.3f\n", convert_number + 273.15);
                getch();
                break;
            case 3:
                printf("\n\t\t\t\t\t\tFahrenheit : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tCelsius    : %.3f\n", (convert_number - 32) * .5556);
                getch();
                break;
            case 4:
                printf("\n\t\t\t\t\t\tFahrenheit : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tKelvin     : %.3f\n", (convert_number + 459.67) * 5/9);
                getch();
                break;
            case 5:
                printf("\n\t\t\t\t\t\tKelvin  : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tCelsius : %.3f\n",  convert_number - 273.15);
                getch();
                break;
            case 6:
                printf("\n\t\t\t\t\t\tKelvin     : ");
                scanf("%f", &convert_number);
                printf("\t\t\t\t\t\tFahrenheit : %.3f\n", convert_number * 9/5 - 459.67);
                getch();
                break;
            case 7:
                main();
                getch();
                break;
            default:
                break;
        }
    system ("cls");
    printf("\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Celsius to Fahrenheit");
    printf("\n\t\t\t\tPress 2 to Convert Celsius to Kelvin");
    printf("\n\t\t\t\tPress 3 to Convert Fahrenheit to Celsius");
    printf("\n\t\t\t\tPress 4 to Convert Fahrenheit to Kelvin");
    printf("\n\t\t\t\tPress 5 to Convert Kelvin to Celsius");
    printf("\n\t\t\t\tPress 6 to Convert Kelvin to Fahrenheit");
    printf("\n\t\t\t\tPress 7 to go main menu");
    printf("\n\t\t\t\tPress Any Key to Continue...");
    scanf("%d", &temperature_number);
    system ("cls");
    printf("\n\n\n\n\n\n\n\n\n\n\n");
    }

    return 0;
}




