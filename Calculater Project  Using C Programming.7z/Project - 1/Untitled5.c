#include<stdio.h>

int main()
{
    int pass = 12345;
    printf("Enter Your Pass : ");
    scanf("%d", &pass);
    if(pass == 12345){
        printf("Success\n");
    }
    else{
        printf("Not Success\n");
    }


    while(pass != 12345){
        printf("Enter Pass Again : ");
        scanf("%d", &pass);
        if(pass == 12345){
            printf("Success\n");
            break;
        }
        else{
            printf("Not Success\n");
        }
    }

}
