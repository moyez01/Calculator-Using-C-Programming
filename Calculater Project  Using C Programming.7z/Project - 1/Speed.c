#include<stdio.h>
#include<conio.h>

void speed()
{
    system("color 4a");
    float centimeter, miter, kilometer, convert_number;
    int energy_number;
    printf("\n\n\n\n\n\n\n\t\t\t\tPress 1 to Convert Meters per Second to Kilometers per Hours");
    printf("\n\t\t\t\tPress 2 to Convert Meters per Second to Miles per Hours");
    printf("\n\t\t\t\tPress 3 to Convert Kilometers per Hours to Meters per Second");
    printf("\n\t\t\t\tPress 4 to Convert Kilometers per Hours to Miles per Hours");
    printf("\n\t\t\t\tPress 5 to Convert Miles per Hours to Meters per Second");
    printf("\n\t\t\t\tPress 6 to Convert Miles per Hours to Kilometers per Hours");
    printf("\n\t\t\t\tPress Any Key to Continue...");
    scanf("%d", &energy_number);
    system ("cls");
    //clrscr();
    printf("\n\n\n\n\n\n\n\n\n\n\n");
    switch(energy_number){
    case 1:
        printf("\n\t\t\t\t\t\tMeters per Second    : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKilometers per Hours : %.2f\n\n", convert_number * 3.60);
        break;
    case 2:
        printf("\n\t\t\t\t\t\tMeters per Second : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tMiles per Hours   : %.2f\n\n", convert_number * 2.24);
        break;
    case 3:
        printf("\n\t\t\t\t\t\tKilometers per Hours : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tMeters per Second    : %.2f\n\n", convert_number * 0.28);
        break;
    case 4:
        printf("\n\t\t\t\t\t\tKilometers per Hours : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tMiles per Hours      : %.2f\n\n", convert_number * 0.62);
        break;
    case 5:
        printf("\n\t\t\t\t\t\tMiles per Hours   : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tMeters per Second : %.2f\n\n", convert_number * 0.45);
        break;
    case 6:
        printf("\n\t\t\t\t\t\tMiles per Hours      : ");
        scanf("%f", &convert_number);
        printf("\t\t\t\t\t\tKilometers per Hours : %.2f\n\n", convert_number * 1.61);
        break;
        }

    getch();
    return 0;
}

